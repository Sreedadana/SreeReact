const Config = require('../config/Config.json');
const ParticipantsConfig = require('../config/Participants.json');
const ParticipantsFormConfig = require('../config/Participants_form.json');


module.exports = {
    getConfig: (req,res) => {
        const dataSourceArray = Config.dataSources;
        const viewArray = Config.views;
        const participantsDataSourceArray = ParticipantsConfig.dataSources;
        const participantsFormDataSourceArray = ParticipantsFormConfig.dataSources;
        const data = dataSourceArray[0];
        const demoView = viewArray[0];
        const participantData = participantsDataSourceArray[0];
        const participantFormData = participantsFormDataSourceArray[0];
        res.json({
            data : data.mockDataSet, 
            demoView : demoView,
            dataStore: Config.views,
            dataSources: dataSourceArray,
            participantsDataStore: ParticipantsConfig.views,
            participantsOperations: participantData.operations,
            participantsFormDataStore: ParticipantsFormConfig.views,
            participantsFormOperations: participantFormData.operations
        });
    },
    getParticipants: (req,res) => {
        const result = [
        {
        "issuerParty": "AMTD",
        "taxId": "5562",
        "editable":false,
        "employment": {
            "employeeNumber": "1234",
            "hireDate": "2000-08-13",
            "terminationDate": null
        },
        "fullName": {
            "given": "JEFFREY",
            "middle": "H",
            "family": "BAIG"
        },
        "addresses": [
            {
            "context": "home",
            "lineOne": "2780 SW 69TH",
            "lineTwo": null,
            "city": "MIAMI",
            "countrySubdivision": null,
            "postalCode": "33155",
            "countryCode": "US"
            },
            {
            "context": "work",
            "lineOne": "456 Work St",
            "lineTwo": null,
            "city": "Fantasy Island",
            "countrySubdivision": null,
            "postalCode": "68750",
            "countryCode": "US"
            }
        ],
        "phoneNumbers": [
            {
            "context": "home",
            "digits": "800-123-1234"
            },
            {
            "context": "work",
            "digits": "5555-555-5555"
            }
        ],
        "emailAddresses": [
            {
            "context": "home",
            "address": "noemail@test.com"
            }
        ],
        "id": 9,
        "promoted": true,
        "birthDate": "1950-08-13",
        "uuid": "daaea3c6-6eea-d2f1-6919-eb3f72196b6b"
        },
        {
        "issuerParty": "AMTD",
        "taxId": "1500",
        "editable":false,
        "employment": {
            "employeeNumber": "20",
            "hireDate": "2010-08-13",
            "terminationDate": "2020-08-13"
        },
        "fullName": {
            "given": "Peter",
            "middle": null,
            "family": "Diglet"
        },
        "addresses": [
            {
            "context": "work",
            "lineOne": "818 Government",
            "lineTwo": null,
            "city": "Chicago",
            "countrySubdivision": "IL",
            "postalCode": "60090",
            "countryCode": "US"
            }
        ],
        "phoneNumbers": [
            {
            "context": "work",
            "digits": "212-555-1212"
            }
        ],
        "emailAddresses": [
            {
            "context": "work",
            "address": "NPE-QAWebTest@tdameritrade.com"
            }
        ],
        "id": 8,
        "promoted": false,
        "birthDate": "1987-12-12",
        "uuid": "6bd633be-bbd4-ddb2-4acd-6c8284f09cca"
        },
        {
        "issuerParty": "AMTD",
        "taxId": "5572",
        "editable":false,
        "employment": {
            "employeeNumber": "16",
            "hireDate": "2010-08-13",
            "terminationDate": "2020-08-13"
        },
        "fullName": {
            "given": "Lee",
            "middle": null,
            "family": "Kyacommon"
        },
        "addresses": [
            {
            "context": "work",
            "lineOne": "15658 noel rd",
            "lineTwo": null,
            "city": "Fantasy Island",
            "countrySubdivision": "IL",
            "postalCode": "60750",
            "countryCode": "US"
            }
        ],
        "phoneNumbers": [
            {
            "context": "work",
            "digits": "212-555-1212"
            }
        ],
        "emailAddresses": [
            {
            "context": "work",
            "address": "NPE-QAWebTest@tdameritrade.com"
            }
        ],
        "id": 6,
        "promoted": false,
        "birthDate": "1987-12-12",
        "uuid": "1070e054-b4ed-1959-bb39-2bb4744d2b26"
        },
        {
        "issuerParty": "AMTD",
        "taxId": "1234",
        "editable":false,
        "employment": {
            "employeeNumber": "32",
            "hireDate": "2000-08-13",
            "terminationDate": null
        },
        "fullName": {
            "given": "Franklin",
            "middle": "Delano",
            "family": "Roosevelt"
        },
        "addresses": [
            {
            "context": "home",
            "lineOne": "1600 Pennsylvania Avenue",
            "lineTwo": null,
            "city": "Washington",
            "countrySubdivision": "DC",
            "postalCode": "20006",
            "countryCode": "US"
            }
        ],
        "phoneNumbers": [
            {
            "context": "work",
            "digits": "555-555-5555"
            }
        ],
        "emailAddresses": [
            {
            "context": "work",
            "address": "NPE-QAWebTest@tdameritrade.com"
            }
        ],
        "id": 5,
        "promoted": false,
        "birthDate": "1978-05-31",
        "uuid": "d879b073-2617-270f-1255-38c488e8e12c"
        },
        {
        "issuerParty": "AAPL",
        "taxId": "0003",
        "editable":false,
        "employment": {
            "employeeNumber": "19",
            "hireDate": "2010-08-13",
            "terminationDate": "2020-08-13"
        },
        "fullName": {
            "given": "Jaw",
            "middle": null,
            "family": "Breaker"
        },
        "addresses": [
            {
            "context": "work",
            "lineOne": "1755 Banclay Hill",
            "lineTwo": null,
            "city": "Beaver",
            "countrySubdivision": "PA",
            "postalCode": "15009",
            "countryCode": "US"
            }
        ],
        "phoneNumbers": [
            {
            "context": "work",
            "digits": "212-555-1212"
            }
        ],
        "emailAddresses": [
            {
            "context": "work",
            "address": "NPE-QAWebTest@tdameritrade.com"
            }
        ],
        "id": 7,
        "promoted": false,
        "birthDate": "1987-12-12",
        "uuid": "b3a9a2ff-1419-1f21-764a-65282e0fb511"
        }
        ];
        res.json({result})
    }    
};
