const configController = require('../controller/configController');
module.exports = function (app, express) {
    const apiRoutes = express.Router();

    apiRoutes.get('/getConfig',configController.getConfig );
    apiRoutes.get('/getParticipants',configController.getParticipants );
    app.use('/api',apiRoutes)
}   