var express = require('express');
var app = express();

var port = process.env.port || 8081;
var cors = require('cors');

var bodyParser = require('body-parser');
app.use(cors());
app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());

var routes = require('./api/routes/routes.js');

routes(app,express);

app.listen(port, function() {
    console.log('Server Listening at ' + port);
});