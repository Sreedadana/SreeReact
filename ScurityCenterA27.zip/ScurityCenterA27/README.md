Below you will find some information on how to perform common tasks.

Initialize the repository and pull into your local or download the repository at:
https://som955@bitbucket.associatesys.local/scm/~som955/securitycenter.git


Folder Structure
-----------------------------
SecurityCenter/
  dist/
   index.html
   main.js
  src/
    images
    js/
      actions/
        Actions.js
        actionTypes.js
        index.js
      components/
        common/
           Footer.js
           Header.js
           Input.js
           Nav.js
           RadioBtn.js
         ViewComponents/
             TableView.js
      Reducers/
         index.js
         initialState.js
         tableReducer.js
      store/
         configureStore.js
      Utils/
         helper.js
      app.js
      index.js
      routes.js
      index.html
      styles/
         tableview.css
  README.md
  node_modules/
  package.json
    

You may create subdirectories inside src. For faster rebuilds, only files inside src are processed by Webpack.
You need to put any JS and CSS files inside src, otherwise Webpack won’t see them.


Available Scripts
------------------------------------

npm install
  -Do this once after you get the project in your local, it will install all the required node modules for the project to run.

npm start
  -Runs the app in the development mode.
  open http://localhost:6127 to view it in browser
  The page will reload if you make edits.

npm run build
  -Builds the app for production to the build folder.
   It correctly bundles React in production mode and optimizes the build for the best performance.


    

      
        
      


          
        
        
     

  
