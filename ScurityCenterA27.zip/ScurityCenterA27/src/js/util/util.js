export function changeDateFormat(dateCurrent) {
    if (dateCurrent !== null || dateCurrent !== '' || dateCurrent !== undefined) {
        const explodeArray = dateCurrent.split("-");
        let dateChanged;
        if(explodeArray.length ===3) {
            dateChanged = `${explodeArray[1]}-${explodeArray[2]}-${explodeArray[0]}`;
        } else {
            dateChanged = dateCurrent;
        }
        return dateChanged;
    } else {
        return dateCurrent;
    }
};

// export function booleanFormatter(data) {
//     return false;
// }

export function changeDateForma2(dateCurrent) {
    if (dateCurrent !== null) {
        const explodeArray = dateCurrent.split("-");
        let dateChanged;
        if(explodeArray.length === 3) {
            dateChanged = `${explodeArray[2]}-${explodeArray[1]}-${explodeArray[0]}`;
        } else {
            dateChanged = dateCurrent;
        }
        return dateChanged;
    } else {
        return dateCurrent;
    }

};