import { SET_CONFIG_DATA, LOAD_TABLE_SUCCESS,UPDATE_FORM_TABLE_ROW,SUBMIT_RECORD,SUBMIT_FORM_RECORD,UPDATE_TABLE_ROW, SET_ALL_PARTICIPANTS, DELETE_TABLE_ROWS_SUCCESS, CREATE_TABLE_ROWS_SUCCESS } from '../actions/actionTypes';
import initialState from './initialState';
import { map, remove, findIndex, filter } from 'lodash';

const DEFAULT_STATE = {
  tg: true
};

const setConfigData = (state = initialState, action) => {
  const newState = {};
  const Config = action.Config.Config;
  Object.assign(newState,state, {data: Config.data, demoView: Config.demoView, dataStore: Config.dataStore, participantsDataStore: Config.participantsDataStore, participantsFormDataStore: Config.participantsFormDataStore, participantsFormOperations: Config.participantsFormOperations, participantsOperations: Config.participantsOperations, dataSources: Config.dataSources})
  return newState;
}
const getParticipants = (state = initialState, action) => {
  const newState = {};
  const filteredParticipants = action.data;
  const formParticipants = action.data;
  Object.assign(newState, state, { participants: filteredParticipants, formParticipants:formParticipants });
  return newState;
};

const onDelete = (state = initialState, action) => {
  let stateData = state.dataset.length > 0 ? state.dataset : state[action.state];
  
  const detaSet = [];
  var foundIndex = -1;
  for (let k = 0; k < stateData.length; k++) {
    const todo = stateData[k];
    if (todo[action.key] !== action.value) {
      detaSet.push(todo);
    } else {
      foundIndex = k;
    }
  }

  const participants = [...state.participants];
  if(foundIndex>=0){
       participants.splice(foundIndex, 1);
       setTimeout(function() {
         alert(action.value + ' row has been deleted successfully')
       }, 500);
  }
  
  const newState = {};
  Object.assign(newState, state, {participants : participants});
  newState.dataset = detaSet;
  newState.deletedAll =detaSet.length <= 0? true: false;
  return newState;
};

const onUpdate = (state = initialState, action) => {
  let stateData = state.dataset.length > 0 ? state.dataset : state[action.state];
  const detaSet = [];
  for (let k = 0; k < stateData.length; k++) {
    var todo = stateData[k];    
    if (todo[action.key] === action.value) {
      var updatedRecord = Object.assign({},todo,{editable:true});
      detaSet.push(updatedRecord);
    } else{
      detaSet.push(todo);
    } 
  }

  const participants  = [...state.participants];
  const newState = {};
  Object.assign(newState, state, {participants : participants});
  newState.dataset = detaSet;
  return newState;
};

const onSubmit = (state = initialState, action) => {
  let stateData = state.dataset.length > 0 ? state.dataset : state[action.state];
  const detaSet = [];
  var updatedRecord = action.value;
  updatedRecord.editable = false;
  updatedRecord.new = false;
  var foundIndex = -1;
  for (let k = 0; k < stateData.length; k++) {
    var todo = stateData[k];
    if (todo[action.uniqueValue] === updatedRecord[action.uniqueValue]) {
      var newRecord = Object.assign({},todo,updatedRecord);
      detaSet.push(newRecord);
      foundIndex = k;
    } else if(todo[action.uniqueValue] === '') {
      var newRecord = Object.assign({},todo,updatedRecord);
      detaSet.push(newRecord);
      foundIndex = k;
    } else{
      detaSet.push(todo);
    } 
  }

  const participants  = [...state.participants];
  if(foundIndex != -1){
    participants.splice(foundIndex,1,updatedRecord);
    setTimeout(function() {
         alert(action.uniqueValue + ': ' + updatedRecord[action.uniqueValue] + ' row has been updated successfully')
       }, 500);
  }
  
  const newState = {};
  Object.assign(newState, state, {participants : participants});
  newState.dataset = detaSet;
  return newState;
};

const onCreate = (state = initialState, action) => {

  const newItem={
    
      "issuerParty": "",
      "taxId": "",
      "employment": {
        "employeeNumber": "",
        "hireDate": "",
        "terminationDate": null
      },
      "fullName": {
        "given": "",
        "middle": "",
        "family": ""
      },
      "addresses": [
        {
          "context": "home",
          "lineOne": "",
          "lineTwo": null,
          "city": "",
          "countrySubdivision": null,
          "postalCode": "",
          "countryCode": ""
        },
        {
          "context": "work",
          "lineOne": "",
          "lineTwo": null,
          "city": "",
          "countrySubdivision": null,
          "postalCode": "",
          "countryCode": ""
        }
      ],
      "phoneNumbers": [
        {
          "context": "home",
          "digits": ""
        },
        {
          "context": "work",
          "digits": ""
        }
      ],
      "emailAddresses": [
        {
          "context": "home",
          "address": ""
        },
        {
          "context": "work",
          "address": ""
        }
      ],
      "id":'',
      "promoted": "",
      "birthDate": "",
      "uuid": "",
      "new": true,
      "editable": true
  }
  const newState = {};
  const participants = [...state.participants, newItem];
  Object.assign(newState, state, { participants: participants });
  newState.dataset = participants;
  setTimeout(function() {
         alert('Created Successfuly')
       }, 500);
  return newState;
}

function tableReducer(state = initialState, action) {

  switch (action.type) {
    case LOAD_TABLE_SUCCESS:
      return {
        ...state, data: action.payload.data,
        selection: action.payload.selection,
        demoView: action.payload.demoView
      };
    case SET_ALL_PARTICIPANTS:
      return getParticipants(state, action);
    case DELETE_TABLE_ROWS_SUCCESS:
      return onDelete(state, action);
    case CREATE_TABLE_ROWS_SUCCESS:
      return onCreate(state, action);
    case UPDATE_TABLE_ROW:
      return onUpdate(state, action);
    case SUBMIT_RECORD:
      return onSubmit(state, action);
    case SET_CONFIG_DATA:
      return setConfigData(state,action);
    default:
      return state;
  }
}

export default tableReducer;
