    import { combineReducers } from 'redux';
import tableReducer from './tableReducer';
import formReducer from './formReducer';

const rootReducer = combineReducers({
  tableReducer,
  formReducer
});

export default rootReducer;
