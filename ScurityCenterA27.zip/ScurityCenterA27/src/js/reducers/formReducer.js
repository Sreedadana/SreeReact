import { EDIT_FORM_RECORD,UPDATE_FORM_RECORD,CANCEL_FORM_SUBMIT,SET_ALL_PARTICIPANTS} from '../actions/actionTypes';
import initialState from './initialState';
import { map, remove, findIndex, filter } from 'lodash';

const DEFAULT_STATE = {
  tg: true
};

const getParticipants = (state = initialState, action) => {
  const newState = {};
  const filteredParticipants = action.data;
  const formParticipants = action.data;
  Object.assign(newState, state, { participants: filteredParticipants, formParticipants:formParticipants });
  console.log(newState);
  return newState;
};

const onFormEdit = (state = initialState, action) => {
  let stateData = state.formDataset.length > 0 ? state.formDataset : state[action.state];
  const detaSet = [];
  for (let k = 0; k < stateData.length; k++) {
    var todo = stateData[k];    
    if (todo[action.key] === action.value) {
      var updatedRecord = Object.assign({},todo,{editable:true,dataUpdated:true});
      detaSet.push(updatedRecord);
    } else{
      detaSet.push(todo);
    } 
  }

  const participants  = [...state.formParticipants];
  const newState = {};
  Object.assign(newState, state, {formParticipants : participants});
  newState.formDataset = detaSet;
  return newState;
}

const onFormUpdate = (state = initialState, action) => {
  let stateData = state.formDataset.length > 0 ? state.formDataset : state[action.state];
  const detaSet = [];
  var updatedRecord = action.value;
  updatedRecord.editable = false;
  updatedRecord.dataUpdated = false;
  var foundIndex = -1;
  for (let k = 0; k < stateData.length; k++) {
    var todo = stateData[k];
    if (todo[action.uniqueValue] === updatedRecord[action.uniqueValue]) {
      var newRecord = Object.assign({},todo,updatedRecord);
      detaSet.push(newRecord);
      foundIndex = k;
    } else{
      detaSet.push(todo);
    } 
  }

  const participants  = [...state.formParticipants];
  if(foundIndex != -1){
    participants.splice(foundIndex,1,updatedRecord);
    setTimeout(function() {
         alert(action.uniqueValue + ': ' + updatedRecord[action.uniqueValue] + ' row has been updated successfully')
       }, 500);
  }
  
  const newState = {};
  Object.assign(newState, state, {formParticipants : participants});
  newState.formDataset = detaSet;
  return newState;
};

const onFormCancel = (state = initialState, action) => {
  let stateData = state.formDataset.length > 0 ? state.formDataset : state[action.state];
  const detaSet = [];
  var updatedRecord = action.value;
  updatedRecord.editable = false;
  updatedRecord.dataUpdated = false;
  var foundIndex = -1;
  for (let k = 0; k < stateData.length; k++) {
    var todo = stateData[k];
    if (todo[action.uniqueValue] === updatedRecord[action.uniqueValue]) {
      var newRecord = Object.assign({},todo,updatedRecord);
      detaSet.push(newRecord);
      foundIndex = k;
    } else{
      detaSet.push(todo);
    } 
  }

  const participants  = [...state.formParticipants];
  if(foundIndex != -1){
    participants.splice(foundIndex,1,updatedRecord);
  }
  
  const newState = {};
  Object.assign(newState, state, {formParticipants : participants});
  newState.formDataset = detaSet;
  return newState;
};

function formReducer(state = initialState, action) {

  switch (action.type) {
    case SET_ALL_PARTICIPANTS:
      return getParticipants(state, action);
    case EDIT_FORM_RECORD:
      return onFormEdit(state, action);
    case UPDATE_FORM_RECORD:
      return onFormUpdate(state, action);
    case CANCEL_FORM_SUBMIT:
      return onFormCancel(state,action);
    default:
      return state;
  }
}

export default formReducer;
