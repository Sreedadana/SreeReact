import React from 'react';
import ReactDOM from 'react-dom';
import { Navbar, NavItem, Nav, Tab, MenuItem, Col, Row } from 'react-bootstrap';
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table';
import Styles from '../../../styles/tableView.css';

class TabsInstance extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const { dataStore, participants, participantsDataStore } = this.props.propData;
    const { onChange } = this.props;
    return (
      <div className="Nav Nav-bar navigation ">
        <Col sm={2}>
          <Tab id="left-tabs-example" defaultactivekey="first">
            <Nav bsStyle="pills" stacked>
              <NavItem className='navigationID' eventKey={1} value="first"
                onClick={({ target }) => onChange("first")}>{dataStore[0].name}</NavItem>
              <NavItem className='navigationID' eventKey={2} value="second"
                onClick={({ target }) => onChange("second")}>{dataStore[1].name}</NavItem>
              <NavItem className='navigationID' eventKey={3} value="third"
                onClick={({ target }) => onChange("third")}>{participantsDataStore[0].name}</NavItem>
              <NavItem className='navigationID' eventKey={4} value="fourth"
                onClick={({ target }) => onChange("fourth")}>{participantsDataStore[0].name + ' Form'}</NavItem>
            </Nav>
          </Tab>
        </Col>
      </div>
    )
  }
};

export default TabsInstance;