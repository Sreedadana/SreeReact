import React, { Component } from 'react';
import Styles from '../../../styles/tableView.css';


export default class Header extends React.Component {
  render() {
    return (
      <div className="Header">
       <h4>This is Header Section .... </h4>
      </div>
    )
  }
}
