import React from 'react';
import Styles from '../../../styles/tableView.css';

export class Divider extends React.Component {
	constructor(){
		super()
	}

render(){
	return(
	
		<div className="divider">
            &nbsp;
        </div>
	);
}
}


export default Divider;
