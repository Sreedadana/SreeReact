import React, { Component } from 'react';
import { render } from 'react-dom';
import { 
    Col,
    HelpBlock,
    FormGroup,
    FormControl,
    ControlLabel
} from 'react-bootstrap';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as Actions from '../../actions/Actions';
import Styles from '../../../styles/tableView.css';
import { changeDateFormat, changeDateForma2 } from './../../util/util';

class FormView extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      checked: false
    }
    this.isUpdated = false;
    this.recordToUpdate = {};
    this.updateRecordParam = this.updateRecordParam.bind(this);
  }

  updateRecordParam(event){
    var id = event.target.id.split('-');
    var value;
    if(event.target.value ==='on') {
      this.setState({checked: event.target.checked});
      this.isUpdated = true;
      value = event.target.checked;
    } else {
      value = event.target.value
    }
    if(id && id.length == 2){
      this.recordToUpdate[id[0]][id[1]] = value;
    } else if(id && id.length > 2){
      if(this.recordToUpdate[id[0]][0].context === id[2]) {
        this.recordToUpdate[id[0]][0][id[1]] = value;
      } else if(this.recordToUpdate[id[0]][1].context === id[2]) {
        this.recordToUpdate[id[0]][1][id[1]] = value;
      }
    } else{
      this.recordToUpdate[event.target.id] = value;
    }
  }
  onUpdate(stateName, uniqueValue) {
    this.props.actions.onFormUpdate(stateName,uniqueValue,this.recordToUpdate);
    this.isUpdated = false;
  }
  onEdit(stateName, uniqueKey, keyValue) {
    this.props.actions.onFormEdit(stateName, uniqueKey, keyValue);
  }
  onCancel(stateName, uniqueKey, record) {
    this.isUpdated = false;
    this.props.actions.onFormCancel(stateName, uniqueKey, record);
  }
  getActionFormFields(Config,stateName, putUniqueKey, putKeyValue,record) {
    const isEditable = record.dataUpdated;
    if (Config.formField) {
      if(isEditable) {
        return (<div>
          <div>
            <input
              name='update'
              type='button'
              value='Update'
              onClick={() => this.onUpdate(stateName, putUniqueKey)}
            />
          </div>
          <div>
            <input
              name='cancel'
              type='button'
              value='Cancel'
              onClick={() => this.onCancel(stateName,putUniqueKey,record)}
            />
          </div>
        </div>);
      }
      return (<div>
        <div>
          <input
            name='edit'
            type='button'
            value='Edit'
            onClick={() => this.onEdit(stateName, putUniqueKey, putKeyValue)}
          />
        </div>
      </div>)
    }
  }
  getTableContent(record, columns,uniqueKey) {
    if(record.editable && !this.isUpdated){
      this.recordToUpdate =JSON.parse(JSON.stringify(record));
    }
    return columns.map((column, columnIndex) => {
      if(column.displayer && column.displayer.pattern) {
        const fieldData = record[column.id];
        const isEditable = record.editable;
        let separator;
        if(column.displayer.separator) {
          if(column.displayer.separator === '\n') {
            separator = <br/>;
          } else {
            separator = column.displayer.separator;
          }
        } else {
          separator = ',';
        }
        var regex = /{([^}]+)}/g;
        var displayPattern = column.displayer.pattern;
        var displayPaternIds;
        var displayIds = [];
        while(displayPaternIds = regex.exec(displayPattern)) {
          displayIds.push(displayPaternIds[1]);
        }
        var formatPaternIds;
        var formatIds = [];
        if(column.formatter && column.formatter.pattern) {
          var formatPattern = column.formatter.pattern;
          while(formatPaternIds = regex.exec(formatPattern)) {
            formatIds.push(formatPaternIds[1]);
          }
        }
        let rowData;
        if(fieldData.constructor === Array) {
          rowData = fieldData.map((field,fieldDataIndex) => {
            if(column.homeChecked && !column.workChecked && field.context === 'home') {
              return (this.getPatternedFields(column.id,field,displayIds,isEditable,column,separator,formatIds));
            } else if(!column.homeChecked && column.workChecked && (field.context === 'work')) {
              return (this.getPatternedFields(column.id,field,displayIds,isEditable,column,separator,formatIds));
            } else if(column.homeChecked && column.workChecked) {
              return (this.getPatternedFields(column.id,field,displayIds,isEditable,column,separator,formatIds));
            }
          });
        } else {
          rowData = this.getPatternedFields(column.id,fieldData,displayIds,isEditable,column,separator,formatIds);
        }
        return (
          <div key={columnIndex} className="formBlock">
          <span><b>{column.label.toUpperCase()}</b></span><br/>
          {rowData}
          </div>
        )
      } else if(column.formatter && column.formatter.name==='booleanFormater') {
        const fieldData = record[column.id];
        if(!column.readOnly) {
          return(record.editable?<div key={columnIndex} className="formBlock"><b>{column.label.toUpperCase()}</b><br/><input type='checkbox' id={column.id} onChange={this.updateRecordParam} checked={this.isUpdated?this.state.checked:this.recordToUpdate[column.id]}/></div>:<div key={columnIndex} className="formBlock"><span><b>{column.label.toUpperCase()}</b></span><br/><span>{fieldData.toString()}</span></div>)
        }
        return (
          <div key={columnIndex} className="formBlock">
            <span><b>{column.label.toUpperCase()}</b></span><br/>
            <span>{fieldData.toString()}</span>
          </div>
        )
      } else {
        const fieldData = (column.formatter) ? this.formatterFinder(column.formatter, record[column.id]) : record[column.id];
        if(!column.readOnly) {
          return(record.editable?<div key={columnIndex} className="formBlock"><b>{column.label.toUpperCase()}</b><br/>{column.formatter && column.formatter.type==='date'?<input type='date' id={column.id} onChange={this.updateRecordParam} defaultValue={record[column.id]}/>:<input type='text' id={column.id} onKeyUp={this.updateRecordParam} defaultValue={fieldData.toString()}/>}</div>:<div key={columnIndex} className="formBlock"><span><b>{column.label.toUpperCase()}</b></span><br/><span>{fieldData.toString()}</span></div>)
        }
        return (
          <div key={columnIndex} className="formBlock">
            <span><b>{column.label.toUpperCase()}</b></span><br/>
            <span>{fieldData.toString()}</span>
          </div>
        )
      }
    });
  }

  getPatternedFields(columnID, record, columns, isEditable, currentColumn, separator, formatIds) {
    const result = columns.map((column,key) => {
      let splitter = false;
      if(key !== 0){
        splitter = true;
      } else {
        splitter = false;
      }
      let fieldData;
      let formatterRequired = false;
      if(currentColumn.formatter) {
        if(currentColumn.formatter.pattern) {
          if(formatIds.indexOf(column) >= 0) {
              fieldData = this.formatterFinder(currentColumn.formatter, record[column]);
              formatterRequired = currentColumn.formatter.type?true:false;
          } else {
            fieldData = record[column];
            formatterRequired = false;
          }
        } else {
            fieldData = this.formatterFinder(currentColumn.formatter, record[column]);
            formatterRequired = currentColumn.formatter.type?true:false;
        }
      } else {
        fieldData = record[column];
        formatterRequired = false;
      }
      return (isEditable?<div key={key}>{column}<br/>{formatterRequired?<input type='date' id={record.context?columnID + '-'+ column + '-'+ record.context:columnID+'-'+column} onChange={this.updateRecordParam} defaultValue={record[column]}/>:<input type='text' id={record.context?columnID + '-'+ column + '-'+ record.context:columnID+'-'+column} onKeyUp={this.updateRecordParam} defaultValue={fieldData}/>}</div>:<span key={key}>{splitter && fieldData?separator:null} {fieldData}</span>)
    });
    return result;
  }
  formatterFinder(formatter, data) {
    var formattedData = null;
    if(formatter.name === 'changeDateFormat') {
       formattedData = changeDateFormat(data);
    } else if(formatter.name === 'changeDateForma2') {
        formattedData = changeDateForma2(data);
    } else {
        formattedData = data;
    }
    return formattedData;
  }

  render() {
    let dataset = ((this.props.datasetViaRedux && this.props.datasetViaRedux.length > 0) || this.props.dataSetDataDeleted) ?
        this.props.datasetViaRedux :
        this.props.dataset
        ;
    let Config = (this.props.demoViewViaRedux && this.props.demoViewViaRedux.length > 0) ?
        this.props.demoViewViaRedux :
        this.props.Config
        ;
    const configColumns = (Config.columns) ? Config.columns : Config;
    const view = Config.id;
    const tableClassName = 'formParticipants';
    let putUniqueValue = '';
    const participantsOperations = this.props.Operations;
    if(participantsOperations !== null) {
      for(var i=0; i<participantsOperations.length; i++) {
        if(participantsOperations[i].hasOwnProperty('put')) {
          putUniqueValue = participantsOperations[i].put;
        }
      }
    } else {
      putUniqueValue = '';
    }

    const displayForm = this.getTableContent(dataset[0], configColumns, putUniqueValue);
    const getActionFormFields = this.getActionFormFields(Config,view,putUniqueValue,dataset[0][putUniqueValue],dataset[0]);
    return (
      <div className="BootstrapForm">
        <Col sm={10}>
        <form className={tableClassName}>
            {displayForm}
            {getActionFormFields}
        </form>
        </Col>
      </div>
    )
  }
}
const mapStateToProps = (state) => {
  return {
    demoViewViaRedux: state.formReducer.demoView,
    datasetViaRedux: state.formReducer.formDataset
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    actions: bindActionCreators(Actions, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(FormView);