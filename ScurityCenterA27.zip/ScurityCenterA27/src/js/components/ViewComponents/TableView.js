import React, { Component } from 'react';
import { render } from 'react-dom';
import { Col } from 'react-bootstrap';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as Actions from '../../actions/Actions';
import Styles from '../../../styles/tableView.css';
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table';
import { changeDateFormat, changeDateForma2 } from './../../util/util';

class TableView extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      checked: false
    }
    this.isUpdated = false;
    this.recordToUpdate = {};
    this.updateRecordParam = this.updateRecordParam.bind(this);
    this.getFirstRowFields = this.getFirstRowFields.bind(this);
  }
  
  onDelete(stateName, uniqueKey, keyValue) {
    this.props.actions.onDelete(stateName, uniqueKey, keyValue);
  }
  
  onUpdate(stateName, uniqueKey, keyValue) {
    this.props.actions.onUpdate(stateName, uniqueKey, keyValue);
  }
  self = this;

  updateRecordParam(event){
    var id = event.target.id.split('-');
    var value;
    if(event.target.value ==='on') {
      value = event.target.checked;
      this.setState({checked: event.target.checked});
      this.isUpdated = true;
    } else {
      value = event.target.value
    }
    if(id && id.length == 2){
      this.recordToUpdate[id[0]][id[1]] = value;
    } else if(id && id.length > 2){
      if(this.recordToUpdate[id[0]][0].context === id[2]) {
        this.recordToUpdate[id[0]][0][id[1]] = value;
      } else if(this.recordToUpdate[id[0]][1].context === id[2]) {
        this.recordToUpdate[id[0]][1][id[1]] = value;
      }
    } else{
      this.recordToUpdate[event.target.id] = value;
    }
  }
  onCreate() {
    this.props.actions.onCreate();
  }
  onSubmit(stateName, uniqueValue) {
    this.props.actions.onSubmit(stateName,uniqueValue,this.recordToUpdate);
    this.isUpdated = false;
  }
  getTableContent(dataset, columns, deleteUniqueValue, putUniqueValue) {
    let ViewFound = false;
    if( this.props.Config.id === 'participants') {
      ViewFound = true;
    } else {
      ViewFound = false;
    }
    const View = this.props.Config.id;
    const participantsOperations = this.props.participantsOperations;
    
    return dataset.map((record, recordIndex) => {
      return (<tr key={recordIndex}>
        {ViewFound?this.getFirstRowFields(View,deleteUniqueValue,record[deleteUniqueValue],putUniqueValue,record[putUniqueValue]):null}
        {this.getRowFields(record, columns, deleteUniqueValue, putUniqueValue)}
      </tr>)
    });
  }
  getFirstRowFields(stateName,deleteUniqueKey,deleteKeyValue, putUniqueKey, putKeyValue) {
    return (
      <td>{this.getActionRowFields(stateName,deleteUniqueKey,deleteKeyValue, putUniqueKey, putKeyValue)}</td>
    )
  }
  getPatternedFields(columnID,record, columns,isEditable,isNew, currentColumn, separator, formatIds) {
    const result = columns.map((column,key) => {
      let splitter = false;
      if(key !== 0){
        splitter = true;
      } else {
        splitter = false;
      }
      let fieldData;
      let formatterRequired = false;
      const columnID = currentColumn.id;
      if(isNew) {
        fieldData = record[column];
        if(currentColumn.formatter) {
          if(currentColumn.formatter.pattern) {
            if(formatIds.indexOf(column) >= 0) {
                formatterRequired = true;
            } else {
              formatterRequired = false;
            }
          } else {
              formatterRequired = true;
          }
        } else {
          formatterRequired = false;
        } 
      } else if(currentColumn.formatter) {
        if(currentColumn.formatter.pattern) {
          if(formatIds.indexOf(column) >= 0) {
              fieldData = this.formatterFinder(currentColumn.formatter, record[column]);
              formatterRequired = true;
          } else {
            fieldData = record[column];
            formatterRequired = false;
          }
        } else {
            fieldData = this.formatterFinder(currentColumn.formatter, record[column]);
            formatterRequired = true;
        }
      } else {
        fieldData = record[column];
        formatterRequired = false;
      }
      return (isEditable?<div key={key}>{column}{formatterRequired?<input type='date' id={record.context?columnID + '-'+ column + '-'+ record.context:columnID+'-'+column} onChange={this.updateRecordParam} defaultValue={record[column]}/>:<input type='text' id={record.context?columnID + '-'+ column + '-'+ record.context:columnID+'-'+column} onKeyUp={this.updateRecordParam} defaultValue={fieldData}/>}</div>:<span key={key}>{splitter && fieldData?separator:null} {fieldData}</span>)
    });
    return result;
  }
  getRowFields(record, columns, deleteKey, putKey) {
    if(record.editable && !this.isUpdated){
      this.recordToUpdate =JSON.parse(JSON.stringify(record));
    }
    return columns.map((column, columnIndex) => {
      if(column.displayer && column.displayer.pattern) {
        const fieldData = record[column.id];
        const isEditable = record.editable;
        const isNew = record.new;
        let separator;
        if(column.displayer.separator) {
          if(column.displayer.separator === '\n') {
            separator = <br/>;
          } else {
            separator = column.displayer.separator;
          }
        } else {
          separator = ',';
        }
        var regex = /{([^}]+)}/g;
        var displayPattern = column.displayer.pattern;
        var displayPaternIds;
        var displayIds = [];
        while(displayPaternIds = regex.exec(displayPattern)) {
          displayIds.push(displayPaternIds[1]);
        }
        var formatPaternIds;
        var formatIds = [];
        if(column.formatter && column.formatter.pattern) {
          var formatPattern = column.formatter.pattern;
          while(formatPaternIds = regex.exec(formatPattern)) {
            formatIds.push(formatPaternIds[1]);
          }
        }
        let rowData;
        if(fieldData.constructor === Array) {
          rowData = fieldData.map((field,fieldDataIndex) => {
            if(column.homeChecked && !column.workChecked && field.context === 'home') {
              return (<div key={fieldDataIndex}>{this.getPatternedFields(column.id,field,displayIds,isEditable,isNew,column,separator,formatIds)}</div>);
            } else if(!column.homeChecked && column.workChecked && (field.context === 'work')) {
              return (<div key={fieldDataIndex}>{ this.getPatternedFields(column.id,field,displayIds,isEditable,isNew,column,separator,formatIds)}</div>);
            } else if(column.homeChecked && column.workChecked) {
              return (<div key={fieldDataIndex}>{this.getPatternedFields(column.id,field,displayIds,isEditable,isNew,column,separator,formatIds)}</div>);
            }
          });
        } else {
          rowData = this.getPatternedFields(column.id,fieldData,displayIds,isEditable,isNew,column,separator,formatIds);
        }
        return (<td key={columnIndex}>
          {rowData}
        </td>)
      } else if(column.formatter && column.formatter.name==='booleanFormater') {
        const fieldData =  record[column.id];
        if(record.new) {
          return (<td key={columnIndex}><div>{column.label}<br/><input type='checkbox' id={column.id} onChange={this.updateRecordParam} checked={this.isUpdated?this.state.checked:this.recordToUpdate[column.id]}/></div></td>);
        } else if (!column.readOnly) {
          return (record.editable? <td key={columnIndex}><div>{column.label}<br/><input type='checkbox' id={column.id} onChange={this.updateRecordParam} checked={this.isUpdated?this.state.checked:this.recordToUpdate[column.id]}/></div></td>:<td key={columnIndex}>{fieldData.toString()}</td>);
        }
        return (<td key={columnIndex}>{fieldData.toString()}</td>);
      } else {
        const columnID = column.id;
        const fieldData = (column.formatter ?this.formatterFinder(column.formatter, record[column.id]) : record[column.id]);
        if(record.new) {
          return (<td key={columnIndex}><div>{column.label}{column.formatter && column.formatter.type === 'date'?<input type='date' id={column.id} onChange={this.updateRecordParam} defaultValue={record[column.id]}/>:<input type='text' id={column.id} onKeyUp={this.updateRecordParam} defaultValue={record[column.id]}/>}</div></td>)  
        } else if (!column.readOnly) {
          return (record.editable? <td key={columnIndex}><div>{column.label}{column.formatter && column.formatter.type==='date'?<input type='date' id={column.id} onChange={this.updateRecordParam} defaultValue={record[column.id]}/>:<input type='text' id={column.id} onKeyUp={this.updateRecordParam} defaultValue={fieldData.toString()}/>}</div></td>:<td key={columnIndex}>{fieldData.toString()}</td>);
        }
        return (<td key={columnIndex}>{fieldData.toString()}</td>);
      }
    });
  }

  getActionRowFields(stateName,deleteUniqueKey,deleteKeyValue, putUniqueKey, putKeyValue) {
    return (<div>
      <div>
        <input
          name='delete'
          type='button'
          value='Delete'
          onClick={() => this.onDelete(stateName, deleteUniqueKey, deleteKeyValue)}
        />
      </div>
      <div>
        <input
          name='update'
          type='button'
          value='Update'
          onClick={() => this.onUpdate(stateName, putUniqueKey, putKeyValue)}
        />
      </div>
    </div>)
  }

  getActionFormFields(Config, uniqueValue) {
    if (Config.formField) {
      return (<div>
        <div>
          <input
            name='CreateRecord'
            type='button'
            value='CreateRecord'
            onClick={() => this.onCreate()}
          />
          <input
            name='submit'
            type='button'
            value='Submit'
            onClick={() => this.onSubmit(Config.name, uniqueValue)}
          />
        </div>
      </div>)
    }
  }

  formatterFinder(formatter, data) {
    var formattedData = null;
    if(formatter.name === 'changeDateFormat') {
       formattedData = changeDateFormat(data);
    } else if(formatter.name === 'changeDateForma2') {
        formattedData = changeDateForma2(data);
    } else {
       formattedData = data;
    }
    return formattedData;
  }

  getHeader(data, thisProps) {
    return data.map( (column,key) => {
      const id = column.id;
      return (<td key={key}><span>{column.label.toUpperCase()}</span></td>);
    })
  }

  render() {
    let dataset = this.props.dataset;
    let Config =  this.props.Config;
    let participantFound = false;
    const configColumns = (Config.columns) ?
      Config.columns :
      Config
      ;
    const view = Config.id;
    let tableClassName;
    if (view === 'authHistory') {
      tableClassName = "authHistory";
      participantFound = false;
    } else if (view === "authSession") {
      tableClassName = 'authSession';
      participantFound = false;
    }
    else if (view === "participants") {
      dataset = ((this.props.datasetViaRedux && this.props.datasetViaRedux.length > 0) || this.props.dataSetDataDeleted) ?
        this.props.datasetViaRedux :
        this.props.dataset
        ;
      Config = (this.props.demoViewViaRedux && this.props.demoViewViaRedux.length > 0) ?
        this.props.demoViewViaRedux :
        this.props.Config
        ;
      participantFound = true;
      tableClassName = 'participants';
    }
    let deleteUniqueValue = '';
    let putUniqueValue = '';
    const participantsOperations = this.props.participantsOperations;
    for(var i=0; i<participantsOperations.length; i++) {
      if(participantsOperations[i].hasOwnProperty('delete')) {
        deleteUniqueValue = participantsOperations[i].delete;
      } else if(participantsOperations[i].hasOwnProperty('put')) {
        putUniqueValue = participantsOperations[i].put;
      }
    }
    const displayList = this.getTableContent(dataset, configColumns, deleteUniqueValue, putUniqueValue);
    const displayHeader = this.getHeader(configColumns, this.props);
    const getActionFormFields = this.getActionFormFields(Config, putUniqueValue);
    return (
      <div className="BootstrapTable">
        <Col sm={10}>
          <table className={`table ${tableClassName}`}>
            <thead>
              <tr className="BootstrapTable">
                {participantFound? <td></td> :null}
                {displayHeader}
              </tr>
            </thead>
            <tbody>
              {displayList}
            </tbody>
          </table>
          {getActionFormFields}
          <br />
        </Col>
      </div>
    )
  }
}
const mapStateToProps = (state) => {
  return {
    data: state.tableReducer.data,
    selection: state.tableReducer.selection,
    demoViewViaRedux: state.tableReducer.demoView,
    dataStore: state.tableReducer.dataStore,
    participants: state.tableReducer.participants,
    datasetViaRedux: state.tableReducer.dataset,
    dataSetDataDeleted:  state.tableReducer.deletedAll,
    participantsDataStore: state.tableReducer.participantsDataStore,
    participantsOperations: state.tableReducer.participantsOperations
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    actions: bindActionCreators(Actions, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(TableView);