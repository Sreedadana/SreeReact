import React, { Component } from 'react';
import { render } from 'react-dom';
import { connect } from 'react-redux';
import { Row } from 'react-bootstrap';
//import moment from 'moment';
import { bindActionCreators } from 'redux';
import * as Actions from './actions/Actions';
import TableView from './components/ViewComponents/TableView';
import FormView from './components/ViewComponents/FormView';
import TabsInstance from './components/Common/Nav';
import Header from './components/Common/Header';
import Footer from './components/Common/Footer';
import Divider from './components/Common/Divider';

class App extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      showConfirmDialog: false
    };
    this.submitConfirm = this.submitConfirm.bind(this);
  }

  componentWillMount() {
    this.props.actions.getParticipants();
  }
  componentDidMount() {
    this.props.actions.getConfigData();
  }

  submitConfirm() {
    this.props.dispatch(getParticipants());
  }

  handleDataSet(value) {
    if(value === 'fourth') {
      const participants = this.props.participants;
      this.props.actions.getTable({ data: participants, selection: 'fourth', demoView: this.props.participantsFormDataStore[0] });
    } else if (value === 'third') {
      const participants = this.props.participants;
      this.props.actions.getTable({ data: participants, selection: 'third', demoView: this.props.participantsDataStore[0] });
    } else
      if (value === 'second') {
        this.props.actions.getTable({ data: this.props.dataSources[1].mockDataSet, selection: 'second', demoView: this.props.dataStore[1] });

      } else {
        this.props.actions.getTable({ data: this.props.dataSources[0].mockDataSet, selection: 'first', demoView: this.props.dataStore[0] });
      }
  };

  getNabar(dataStore) {
    return (
      <TabsInstance propData={dataStore} onChange={(value) => this.handleDataSet(value)} />
    );
  }
  onChange() {
    // parent class change handler is always called with field name and value
    // this.setState({ [field]: value });
  }
  render() {
    return (
      <div className="1">
        <Header />
        <Divider />

        {this.props.dataStore !== null && this.props.participantsDataStore !== null && this.props.dataSources? this.getNabar(this.props): null}
        <div className="container">
          <Row sm={10}>
            {(this.props.demoView !== null && this.props.participantsOperations !== null && this.props.participantsFormOperations !== null) ? this.props.selection === 'fourth'? <FormView Operations={this.props.participantsFormOperations} Config={this.props.demoView} dataset={this.props.formParticipants} onChange={this.onChange.bind(this)} />: <TableView Config={this.props.demoView} dataset={this.props.data} onChange={this.onChange.bind(this)} />:null}
          </Row>
        </div>
        <Footer />
      </div>
    );
  }
}


const mapStateToProps = (state) => {
  return {
    data: state.tableReducer.data,
    selection: state.tableReducer.selection,
    formParticipants: state.tableReducer.formParticipants,
    demoView: state.tableReducer.demoView,
    dataStore: state.tableReducer.dataStore,
    participants: state.tableReducer.participants,
    participantsDataStore: state.tableReducer.participantsDataStore,
    participantsOperations: state.tableReducer.participantsOperations,
    participantsFormDataStore: state.tableReducer.participantsFormDataStore,
    participantsFormOperations: state.tableReducer.participantsFormOperations,
    dataSources: state.tableReducer.dataSources
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    actions: bindActionCreators(Actions, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(App);