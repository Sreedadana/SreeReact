import React from 'react';
import { BrowserRouter as Router,Route,Switch } from 'react-router-dom';
import App from './app';

export default () => (
  <Router>
    <div>
      <Route exact path='/' component = {App} />
    </div>
  </Router>
);
