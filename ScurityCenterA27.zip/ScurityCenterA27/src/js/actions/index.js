import axios from 'axios';
import { SET_CONFIG_DATA, LOAD_TABLE_SUCCESS,SUBMIT_RECORD,UPDATE_TABLE_ROW,CANCEL_FORM_SUBMIT,EDIT_FORM_RECORD,UPDATE_FORM_RECORD,SET_ALL_PARTICIPANTS, DELETE_TABLE_ROWS_SUCCESS,CREATE_TABLE_ROWS_SUCCESS } from '../actions/actionTypes';
const HEADER_CONFIG = {
  headers: {
    'Authorization': 'Bearer dujOpmrFLljw+hQ6WbfRPxZxRg48rX0BOmzQI1w5o3bBAe170l1IoHbgV8nCRGUhH0HOygDJLKPxpF6Yp683HYQomGKi7ifgPklqfMcLhfj805kbCk7h3y/ut4mOIsmEUkPXMTQ7NOuFeg22OuXRzgThhAsCFdtYdeuBeMFaEENRkiZgo+KewPyOmBO33vsEPziCw9gpclhNX7rFJRiCpdZdTEpVqvhwMhg8qlg4IgHOBTE83w8V7ix/DVOLJBb0aMNwfiysFAGDD4a5vheKWvqLWcHwFjhAws0o96WMJYeKggA/GosbTxln5RVj2dh889HgCF4sw9U3Xyq29iyYFwmZ7nvYJ/5kZhgp7DU+WeR3udCD5Cf/Z6MxU40Ad9NoRF3LeVChf/hGIVkllaRSBLnnwVF1fCpaia5NcHjIgrg1jheQYwKZbgVZze+202-PoS1ghGbmpshooEsJx5Pj58hWZvYalKAjdiU3mv5LfrpYXXCZ33UvJFwERAfQKoeiCFdq+OigfXL+2CRDl8XPcHV0XXpR7iqUWxwOdpPeGnTdJjtJC0kK5u6DpThrP1MnfEcXRLltHmII0YObFuiahwJ8sJjZKJkzEsh3989McYbrShviKdeCCMsbKgvRu0SrXW2WUq2dhgNERbOou5J4LD6kE65LkppzvbhFuBYoopTGyKJPlcKA7iR8eELGGN0aeXDCMs3AfgjcHESv8ZLTeYhUrGlmDn6fkBb8YK5ndUqvADNT5sUynffy2ONYjSY+sOb9MmOBpttep66zVwNrUziPYFBhgDf9cXdJ8O3tZf4eP00xpsFR2LdLmTzt7cw9Vf62ajZrStHG9PolEK8RuOxTuQPKB7vAS9B6J/A3S9k/+jUN6AQlvbMHnmR8BIXhQ9ikw7pPg+WE=222FD3x19z9sWBHDJACbC00B75E',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'en-US,en;q=0.9',
    'Cache-Control': 'no-cache',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET',
    'Content-Type': 'application/json',
  }
};
const api_Server = 'http://localhost:8081';

export const getConfigData = () => {
  return dispatch => {
    const req = axios.get(api_Server + "/api/getConfig", HEADER_CONFIG);
    req.then(resp => {
      dispatch(setConfigData({Config: resp.data}));
    }).catch(err => {});
    return req;
  }
};

export const setConfigData = (Config) => {
  return {
    type: SET_CONFIG_DATA,
    Config
  }
} 
export function onDelete(stateName, uniqueKey, keyValue) {
  return {
    type: DELETE_TABLE_ROWS_SUCCESS,
    state: stateName,
    key: uniqueKey,
    value: keyValue
  }
};

export function onUpdate(stateName, uniqueKey, keyValue) {
  return {
    type: UPDATE_TABLE_ROW,
    state: stateName,
    key: uniqueKey,
    value: keyValue
  }
};

export function onSubmit(stateName,uniqueValue,recordToUpdate) {
  return {
    type: SUBMIT_RECORD,
    value: recordToUpdate,
    state: stateName,
    uniqueValue: uniqueValue
  }
};


export function onFormEdit(stateName, uniqueKey, keyValue) {
  return {
    type: EDIT_FORM_RECORD,
    state: stateName,
    key: uniqueKey,
    value: keyValue
  }
};

export function onFormUpdate(stateName,uniqueValue,recordToUpdate) {
  return {
    type: UPDATE_FORM_RECORD,
    value: recordToUpdate,
    state: stateName,
    uniqueValue: uniqueValue
  }
};

export function onFormCancel(stateName,uniqueValue,recordToUpdate) {
  return {
    type: CANCEL_FORM_SUBMIT,
    value: recordToUpdate,
    state: stateName,
    uniqueValue: uniqueValue
  }
};

export function onCreate() {
  return {
    type: CREATE_TABLE_ROWS_SUCCESS,
    //state: stateName,
    // value: keyValue
  }
};


export const getTable = (table) => {
  return {
    type: LOAD_TABLE_SUCCESS,
    payload: table
  }
};

// export function getParticipants() {
//   //return (dispatch) => {
//   //   axios
//   //     .get('http://ste07lvsspapp01.iteclientsys.local:8080/stock-plan-service-v1/participants', HEADER_CONFIG)
//   //     //.get('http://devctlvrefapp02.iteclientsys.local:8080/reference-data-service-v1/types', HEADER_CONFIG)
//   //     .then(response => {
//   //       console.log(response.data);
//   // dispatch({
//   //   type: GET_ALL_PARTICIPANTS,
//   //   data: response.data
//   // });
//   //})
//   // .catch(err => {
//   //   // dispatch({ type: OversightReportType.OVERSIGHT_ERROR, message: err.response.data.message });
//   // });
//   // };
//   //   return {
//   //   type: GET_ALL_PARTICIPANTS,
//   //   data: result
//   // }
// }


export const getParticipants = () => {
  return dispatch => {
    const req = axios.get(api_Server + "/api/getParticipants", HEADER_CONFIG);
    req.then(resp => {
      dispatch(setParticipants({result: resp.data.result}));
    }).catch(err => {});
    return req;
  }
};

export const setParticipants = (result) => {
  return {
    type: SET_ALL_PARTICIPANTS,
    data: result.result
  }
} 



