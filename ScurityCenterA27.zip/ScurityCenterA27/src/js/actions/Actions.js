export {
    getTable,
    getParticipants,
    onDelete,
    onCreate,
    onUpdate,
    onSubmit,
    onFormEdit,
    onFormUpdate,
    onFormCancel,
    getConfigData,
    setConfigData
} from './index';
